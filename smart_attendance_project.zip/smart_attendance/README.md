# Smart Attendance Management System

A PHP + MySQL attendance website with Admin, Faculty and Student roles. Students sign in using their USN or registered email address.

## Requirements
- XAMPP (Apache + PHP 8.0+ + MySQL/MariaDB)
- A modern browser

## Installation (XAMPP on Windows)
1. Extract the `smart_attendance` folder into `C:\xampp\htdocs\`.
2. Start **Apache** and **MySQL** from the XAMPP Control Panel.
3. Open `http://localhost/phpmyadmin`.
4. Select **Import**, choose `smart_attendance/database.sql`, then click **Import**.
5. Open `smart_attendance/config/database.php`. The defaults are host `localhost`, database `smart_attendance`, user `root`, and an empty password. Change these if your MySQL setup differs.
6. Visit `http://localhost/smart_attendance/`.

## Demo logins
All demo accounts use password `password`.

| Role | Login |
|---|---|
| Admin | `admin@college.edu` |
| Faculty | `ananya@college.edu` |
| Student | USN `1XX23CS001` |

A second sample student is `1XX23CS002` (email `sneha@college.edu`).

## First-use workflow
1. Sign in as Admin.
2. Add students in **Students**. Each USN and email must be unique; set an initial password of at least 8 characters.
3. Add faculty in **Faculty**.
4. Add subjects in **Subjects** and assign each subject to a faculty member.
5. Sign out and sign in as the assigned faculty member.
6. Open **Mark attendance**, choose a subject and date, set each student as Present or Absent, then save.
7. Sign in as a student using their USN and password to see the dashboard and attendance history.
8. Admin and faculty can review reports.

## Important implementation notes
- Passwords are stored using PHP `password_hash()` and checked with `password_verify()`.
- Database access uses PDO prepared statements.
- Forms use session-based CSRF tokens.
- Attendance has a unique constraint for student + subject + date. Saving a session updates existing entries rather than creating duplicate rows.
- A student's attendance percentage is calculated as present records divided by all recorded records for that student/subject.
- This is a starter academic project. Before real deployment, use HTTPS, change all demo passwords, configure a non-root database user, add password reset and audit features, and restrict faculty/student access according to your institution's rules.
- The example USNs are placeholders. Replace them with your college's actual USN format and real student records.
