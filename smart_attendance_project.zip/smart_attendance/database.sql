CREATE DATABASE IF NOT EXISTS smart_attendance CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE smart_attendance;

CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  email VARCHAR(160) NOT NULL UNIQUE,
  usn VARCHAR(30) UNIQUE NULL,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('admin','faculty','student') NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE subjects (
  id INT AUTO_INCREMENT PRIMARY KEY,
  subject_code VARCHAR(20) NOT NULL UNIQUE,
  subject_name VARCHAR(120) NOT NULL,
  semester TINYINT UNSIGNED NOT NULL,
  faculty_id INT NULL,
  FOREIGN KEY (faculty_id) REFERENCES users(id) ON DELETE SET NULL
);

CREATE TABLE attendance (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  student_id INT NOT NULL,
  subject_id INT NOT NULL,
  attendance_date DATE NOT NULL,
  status ENUM('present','absent') NOT NULL,
  marked_by INT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY unique_student_subject_day (student_id, subject_id, attendance_date),
  FOREIGN KEY (student_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (subject_id) REFERENCES subjects(id) ON DELETE CASCADE,
  FOREIGN KEY (marked_by) REFERENCES users(id)
);

-- Demo accounts: password for all three is password
-- Change passwords immediately after first login in a real deployment.
INSERT INTO users (name,email,usn,password_hash,role) VALUES
('System Administrator','admin@college.edu',NULL,'$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2uheWG/igi.','admin'),
('Ananya Rao','ananya@college.edu',NULL,'$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2uheWG/igi.','faculty'),
('Rahul Kumar','rahul@college.edu','1XX23CS001','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2uheWG/igi.','student'),
('Sneha Patil','sneha@college.edu','1XX23CS002','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2uheWG/igi.','student');

INSERT INTO subjects (subject_code,subject_name,semester,faculty_id) VALUES
('CS301','Java Programming',3,2),
('CS302','Computer Organization',3,2),
('CS303','Digital Logic Design',3,2);

INSERT INTO attendance (student_id,subject_id,attendance_date,status,marked_by) VALUES
(3,1,CURDATE() - INTERVAL 8 DAY,'present',2),
(3,1,CURDATE() - INTERVAL 7 DAY,'present',2),
(3,1,CURDATE() - INTERVAL 6 DAY,'absent',2),
(3,1,CURDATE() - INTERVAL 5 DAY,'present',2),
(3,2,CURDATE() - INTERVAL 8 DAY,'present',2),
(3,2,CURDATE() - INTERVAL 7 DAY,'absent',2),
(3,2,CURDATE() - INTERVAL 6 DAY,'present',2),
(4,1,CURDATE() - INTERVAL 8 DAY,'present',2),
(4,1,CURDATE() - INTERVAL 7 DAY,'present',2);
