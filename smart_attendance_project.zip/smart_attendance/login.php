<?php
require_once __DIR__.'/config/database.php';
require_once __DIR__.'/includes/auth.php';
if (!empty($_SESSION['user'])) { header('Location: '. $_SESSION['user']['role'].'/dashboard.php'); exit; }
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  verify_csrf();
  $identity = trim($_POST['identity'] ?? '');
  $password = $_POST['password'] ?? '';
  $stmt = $pdo->prepare('SELECT id,name,email,usn,password_hash,role FROM users WHERE email = :email OR usn = :usn LIMIT 1');
  $stmt->execute(['email'=>$identity, 'usn'=>$identity]);
  $user = $stmt->fetch();
  if ($user && password_verify($password, $user['password_hash'])) {
    session_regenerate_id(true);
    unset($user['password_hash']);
    $_SESSION['user'] = $user;
    header('Location: '.$user['role'].'/dashboard.php'); exit;
  }
  $error = 'Invalid USN/email or password.';
}
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Sign in | Smart Attendance</title><link rel="stylesheet" href="assets/style.css"></head><body>
<div class="login-page"><section class="login-hero"><div class="brand"><span class="brand-mark">SA</span> Smart Attendance</div><div class="eyebrow">CAMPUS ATTENDANCE, SIMPLIFIED</div><h1>Every class.<br>Every record.<br>One smart place.</h1><p>A simple, secure way for students, faculty and administrators to manage attendance and stay informed.</p></section>
<section class="login-form-side"><form class="login-box" method="post"><div class="eyebrow">WELCOME BACK</div><h2>Sign in to your account</h2><p class="muted">Use your USN or registered email address.</p>
<?php if($error): ?><div class="alert error"><?= h($error) ?></div><?php endif; ?>
<input type="hidden" name="csrf" value="<?= h(csrf_token()) ?>">
<div class="field"><label>USN / Email</label><input name="identity" required autocomplete="username" placeholder="e.g. 1XX23CS001"></div>
<div class="field"><label>Password</label><input type="password" name="password" required autocomplete="current-password" placeholder="Enter your password"></div>
<button class="btn" type="submit">Sign in securely →</button>
<div class="hint">Demo login: <strong>admin@college.edu</strong>, <strong>ananya@college.edu</strong>, or USN <strong>1XX23CS001</strong><br>Password for all demo accounts: <strong>password</strong></div>
</form></section></div></body></html>
