<?php
session_start();
if (!empty($_SESSION['user'])) {
  $role = $_SESSION['user']['role'];
  header('Location: ' . $role . '/dashboard.php');
} else header('Location: login.php');
exit;
