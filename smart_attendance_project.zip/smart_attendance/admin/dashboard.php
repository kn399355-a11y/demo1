<?php
require_once '../config/database.php'; require_once '../includes/auth.php'; require_role('admin');
$pageTitle='Admin dashboard';
$students=(int)$pdo->query("SELECT COUNT(*) FROM users WHERE role='student'")->fetchColumn();
$faculty=(int)$pdo->query("SELECT COUNT(*) FROM users WHERE role='faculty'")->fetchColumn();
$subjects=(int)$pdo->query("SELECT COUNT(*) FROM subjects")->fetchColumn();
$today=(int)$pdo->query("SELECT COUNT(*) FROM attendance WHERE attendance_date=CURDATE()")->fetchColumn();
$recent=$pdo->query("SELECT a.attendance_date,u.name,u.usn,s.subject_name,a.status FROM attendance a JOIN users u ON u.id=a.student_id JOIN subjects s ON s.id=a.subject_id ORDER BY a.attendance_date DESC,a.id DESC LIMIT 8")->fetchAll();
include '../includes/header.php'; ?>
<div class="grid">
<div class="card"><span class="stat-icon">♙</span><div class="stat-label">TOTAL STUDENTS</div><div class="stat-value"><?= $students ?></div><div class="stat-note">Registered student accounts</div></div>
<div class="card"><span class="stat-icon">♟</span><div class="stat-label">FACULTY MEMBERS</div><div class="stat-value"><?= $faculty ?></div><div class="stat-note">Active faculty accounts</div></div>
<div class="card"><span class="stat-icon">▤</span><div class="stat-label">SUBJECTS</div><div class="stat-value"><?= $subjects ?></div><div class="stat-note">Subjects configured</div></div>
<div class="card"><span class="stat-icon">✓</span><div class="stat-label">TODAY'S RECORDS</div><div class="stat-value"><?= $today ?></div><div class="stat-note">Attendance entries today</div></div>
</div>
<div class="panel"><div class="panel-head"><h2>Recent attendance activity</h2><a class="btn secondary small" href="reports.php">View reports</a></div><div class="table-wrap"><table><thead><tr><th>Date</th><th>Student</th><th>USN</th><th>Subject</th><th>Status</th></tr></thead><tbody>
<?php foreach($recent as $r): ?><tr><td><?= h($r['attendance_date']) ?></td><td><?= h($r['name']) ?></td><td><?= h($r['usn']) ?></td><td><?= h($r['subject_name']) ?></td><td><span class="pill <?= h($r['status']) ?>"><?= ucfirst(h($r['status'])) ?></span></td></tr><?php endforeach; ?>
<?php if(!$recent): ?><tr><td colspan="5" class="empty">No attendance records yet.</td></tr><?php endif; ?></tbody></table></div></div>
<?php include '../includes/footer.php'; ?>
