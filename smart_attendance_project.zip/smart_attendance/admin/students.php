<?php
require_once '../config/database.php'; require_once '../includes/auth.php'; require_role('admin');
$pageTitle='Student management'; $message='';
if($_SERVER['REQUEST_METHOD']==='POST'){verify_csrf();$name=trim($_POST['name']??'');$email=trim($_POST['email']??'');$usn=strtoupper(trim($_POST['usn']??''));$password=$_POST['password']??'';
 if($name&&filter_var($email,FILTER_VALIDATE_EMAIL)&&$usn&&strlen($password)>=8){try{$q=$pdo->prepare("INSERT INTO users(name,email,usn,password_hash,role) VALUES(?,?,?,?, 'student')");$q->execute([$name,$email,$usn,password_hash($password,PASSWORD_DEFAULT)]);$message='Student account created.';}catch(PDOException $e){$message='Could not add student. Check that email and USN are unique.';}}
 else $message='Enter valid details. Password must contain at least 8 characters.';}
$rows=$pdo->query("SELECT id,name,email,usn,created_at FROM users WHERE role='student' ORDER BY name")->fetchAll();
include '../includes/header.php'; ?>
<?php if($message): ?><div class="alert"><?= h($message) ?></div><?php endif; ?>
<div class="panel"><div class="panel-head"><h2>Add a student</h2><span class="muted">USN is the student's unique college identifier</span></div><form method="post"><input type="hidden" name="csrf" value="<?= h(csrf_token()) ?>"><div class="form-grid">
<div class="field"><label>Full name</label><input name="name" required></div><div class="field"><label>USN</label><input name="usn" required placeholder="1XX23CS001"></div><div class="field"><label>Email</label><input type="email" name="email" required></div><div class="field"><label>Temporary password</label><input type="password" name="password" minlength="8" required></div></div><div class="form-actions"><button class="btn">Create student</button></div></form></div>
<div class="panel"><div class="panel-head"><h2>Student directory</h2><input style="max-width:240px" placeholder="Search students..." data-filter="#students-table"></div><div class="table-wrap"><table id="students-table"><thead><tr><th>Name</th><th>USN</th><th>Email</th><th>Registered</th></tr></thead><tbody><?php foreach($rows as $r): ?><tr><td><?= h($r['name']) ?></td><td><strong><?= h($r['usn']) ?></strong></td><td><?= h($r['email']) ?></td><td><?= h($r['created_at']) ?></td></tr><?php endforeach; ?></tbody></table></div></div>
<?php include '../includes/footer.php'; ?>
