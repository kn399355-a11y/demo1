document.addEventListener('click', function (event) {
  const confirmLink = event.target.closest('[data-confirm]');
  if (confirmLink && !confirm(confirmLink.dataset.confirm)) event.preventDefault();
});
document.querySelectorAll('[data-filter]').forEach(input => {
  input.addEventListener('input', () => {
    const target = document.querySelector(input.dataset.filter);
    if (!target) return;
    const term = input.value.toLowerCase();
    target.querySelectorAll('tbody tr').forEach(row => {
      row.hidden = !row.textContent.toLowerCase().includes(term);
    });
  });
});
