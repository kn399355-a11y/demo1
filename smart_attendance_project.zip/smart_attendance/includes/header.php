<?php
require_once __DIR__ . '/auth.php';
$user = current_user();
$pageTitle = $pageTitle ?? 'Dashboard';
$role = $user['role'] ?? '';
$root = '../';
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= h($pageTitle) ?> | Smart Attendance</title>
  <link rel="stylesheet" href="../assets/style.css">
</head>
<body>
<div class="app-shell">
  <aside class="sidebar">
    <a class="brand" href="<?= $role === 'admin' ? 'dashboard.php' : ($role === 'faculty' ? 'dashboard.php' : 'dashboard.php') ?>">
      <span class="brand-mark">SA</span><span>Smart<span class="brand-light">Attendance</span></span>
    </a>
    <div class="nav-label">WORKSPACE</div>
    <nav>
      <a class="nav-link" href="dashboard.php"><span>▦</span> Dashboard</a>
      <?php if ($role === 'admin'): ?>
        <a class="nav-link" href="students.php"><span>♙</span> Students</a>
        <a class="nav-link" href="faculty.php"><span>♟</span> Faculty</a>
        <a class="nav-link" href="subjects.php"><span>▤</span> Subjects</a>
        <a class="nav-link" href="reports.php"><span>▥</span> Reports</a>
      <?php elseif ($role === 'faculty'): ?>
        <a class="nav-link" href="mark_attendance.php"><span>✓</span> Mark attendance</a>
        <a class="nav-link" href="reports.php"><span>▥</span> Reports</a>
      <?php else: ?>
        <a class="nav-link" href="attendance.php"><span>▤</span> My attendance</a>
      <?php endif; ?>
    </nav>
    <div class="sidebar-bottom">
      <div class="user-mini"><div class="avatar"><?= strtoupper(substr($user['name'] ?? 'U',0,1)) ?></div><div><strong><?= h($user['name'] ?? '') ?></strong><small><?= ucfirst(h($role)) ?></small></div></div>
      <a class="nav-link logout" href="../logout.php"><span>↪</span> Sign out</a>
    </div>
  </aside>
  <main class="main-content">
    <header class="topbar"><div><div class="eyebrow">SMART ATTENDANCE SYSTEM</div><h1><?= h($pageTitle) ?></h1></div><div class="topbar-right"><span class="status-dot"></span><span><?= h($user['name'] ?? '') ?></span></div></header>
